Please read the [common contributing guidelines](https://github.com/open-eid/org/blob/master/CONTRIBUTING.md) before you continue!
